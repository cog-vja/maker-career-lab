v3.17 diagnostics only. Never replace site company-data.js. Source reconciliation is not publication approval.
